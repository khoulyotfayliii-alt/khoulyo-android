package com.khoulyo.tuktuk;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    KView v;
    static final String WA = "96170309657";
    @Override public void onCreate(Bundle b){ super.onCreate(b); getWindow().setStatusBarColor(Color.rgb(5,9,10)); getWindow().setNavigationBarColor(Color.rgb(5,9,10)); v=new KView(this); setContentView(v); }
    @Override public void onBackPressed(){ if(v.page!=0){v.page=0;v.invalidate();} else super.onBackPressed(); }
    void openUrl(String u){ try{startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(u)));}catch(Exception e){Toast.makeText(this,"تعذر فتح التطبيق",Toast.LENGTH_SHORT).show();} }
    void call(){ startActivity(new Intent(Intent.ACTION_DIAL,Uri.parse("tel:+"+WA))); }
    void whatsapp(String text){ openUrl("https://wa.me/"+WA+"?text="+Uri.encode(text)); }
}

class KView extends View {
    MainActivity a; Paint p=new Paint(Paint.ANTI_ALIAS_FLAG); int page=0,W,H; final int BG=Color.rgb(5,12,14),CARD=Color.rgb(24,32,34),RED=Color.rgb(242,25,32),YELLOW=Color.rgb(255,201,35),BLUE=Color.rgb(25,125,245),GREEN=Color.rgb(0,185,100),WHITE=Color.WHITE,MUTED=Color.rgb(185,190,192); ArrayList<Order> orders=new ArrayList<>();
    String type="", from="", to="", extra="", time="الآن";
    KView(MainActivity c){super(c);a=c; load(); setFocusable(true);}
    void load(){String raw=a.getPreferences(0).getString("orders",""); if(!raw.isEmpty()) for(String s:raw.split("\\n",-1)){if(s.trim().isEmpty())continue;String[] x=s.split("\\|",-1);if(x.length>=5)orders.add(new Order(x[0],x[1],x[2],x[3],x[4]));}}
    void save(){StringBuilder b=new StringBuilder();for(Order o:orders)b.append(o.type).append('|').append(o.from).append('|').append(o.to).append('|').append(o.time).append('|').append(o.note.replace("|"," ")).append('\n');a.getPreferences(0).edit().putString("orders",b.toString()).apply();}
    void bg(Canvas c){c.drawColor(BG);} void rect(Canvas c,float l,float t,float r,float b,int col,float rad){p.setColor(col);c.drawRoundRect(l,t,r,b,rad,rad,p);} 
    void txt(Canvas c,String s,float x,float y,float size,int col,boolean bold){p.setColor(col);p.setTextSize(size);p.setTypeface(Typeface.create("sans",bold?Typeface.BOLD:Typeface.NORMAL));p.setTextAlign(Paint.Align.RIGHT);c.drawText(s,x,y,p);} 
    void center(Canvas c,String s,float x,float y,float size,int col,boolean bold){p.setColor(col);p.setTextSize(size);p.setTypeface(Typeface.create("sans",bold?Typeface.BOLD:Typeface.NORMAL));p.setTextAlign(Paint.Align.CENTER);c.drawText(s,x,y,p);} 
    void header(Canvas c,String title){txt(c,"‹",32,58,40,WHITE,false);txt(c,title,W-25,53,23,WHITE,true);} 
    void button(Canvas c,String s,float y,int col){rect(c,22,y,W-22,y+58,col,14);center(c,s,W/2,y+37,17,col==YELLOW?Color.BLACK:WHITE,true);} 
    @Override protected void onDraw(Canvas c){W=getWidth();H=getHeight();bg(c);switch(page){case 0:home(c);break;case 1:form(c,"طلب مشوار",RED);break;case 2:delivery(c);break;case 3:form(c,"نقل الطلاب",BLUE);break;case 4:form(c,"نقل الموظفين",YELLOW);break;case 5:orders(c);break;case 6:more(c);break;case 7:map(c);break;case 8:details(c);break;case 9:profile(c);break;case 10:notifications(c);break;}}
    void home(Canvas c){
        txt(c,"☰",25,57,29,WHITE,false);center(c,"K",W/2-28,61,47,RED,true);txt(c,"Khoulyo",W/2+90,58,26,WHITE,true);center(c,"النبطية و ضواحيها",W/2,112,23,WHITE,true);center(c,"نوصلك بكل أمان",W/2,139,17,WHITE,false);
        rect(c,20,160,W-20,285,Color.rgb(13,23,25),18);center(c,"🛺",W/2,245,72,WHITE,false);center(c,"Khoulyo TUKTUK",W/2,195,24,RED,true);
        tile(c,20,305,W/2-7,390,RED,"🚗","طلب مشوار");tile(c,W/2+7,305,W-20,390,YELLOW,"📦","توصيل أغراض");tile(c,20,400,W/2-7,485,CARD,"🎓","نقل الطلاب");tile(c,W/2+7,400,W-20,485,CARD,"💼","نقل الموظفين");
        rect(c,20,500,W/2-7,548,GREEN,13);center(c,"واتساب الآن",W/4,531,15,WHITE,true);rect(c,W/2+7,500,W-20,548,RED,13);center(c,"اتصل الآن",W*3/4,531,15,WHITE,true);center(c,"◷  من 6 صباحاً حتى 12 ليلاً",W/2,585,16,WHITE,true);center(c,"❤️ دائماً في خدمتكم",W/2,615,15,MUTED,false);bottom(c,0);
    }
    void tile(Canvas c,float l,float t,float r,float b,int col,String ic,String s){rect(c,l,t,r,b,col,16);center(c,ic,(l+r)/2,t+37,29,col==YELLOW?Color.BLACK:WHITE,false);center(c,s,(l+r)/2,t+72,16,col==YELLOW?Color.BLACK:WHITE,true);}
    void form(Canvas c,String title,int col){header(c,title);field(c,"مكان الانطلاق",from.isEmpty()?"مثال: النبطية":from,105);field(c,title.equals("نقل الطلاب")?"المدرسة / الجامعة":"الوجهة",to.isEmpty()?"مثال: كفررمان":to,190);field(c,"الوقت (اختياري)",time,275);field(c,"ملاحظات (اختياري)",extra.isEmpty()?"مثال: قرب المدرسة...":extra,360);button(c,"إرسال الطلب  ➤",450,col);center(c,"نوصلك بأسرع وقت ❤️",W/2,575,15,MUTED,false);}
    void delivery(Canvas c){header(c,"توصيل أغراض");field(c,"نوع الغرض",type.isEmpty()?"اختر نوع الغرض":type,105);field(c,"مكان الاستلام",from.isEmpty()?"مثال: النبطية":from,190);field(c,"مكان التسليم",to.isEmpty()?"مثال: تول":to,275);field(c,"ملاحظات (اختياري)",extra.isEmpty()?"مثال: حساس، سريع ...":extra,360);button(c,"إرسال الطلب  ➤",450,YELLOW);}
    void field(Canvas c,String lab,String val,float y){txt(c,lab,W-32,y,15,WHITE,true);rect(c,22,y+12,W-22,y+62,CARD,11);txt(c,val,W-40,y+44,14,val.startsWith("مثال")||val.startsWith("اختر")?MUTED:WHITE,false);}
    void orders(Canvas c){header(c,"طلباتي");rect(c,20,80,W/2,130,RED,12);center(c,"الحالية",W/4,112,16,WHITE,true);center(c,"السابقة",W*3/4,112,16,WHITE,false);if(orders.size()==0){center(c,"ما عندك طلبات بعد",W/2,270,18,MUTED,true);}else{float y=145;for(int i=orders.size()-1;i>=0&&y<H-90;i--){Order o=orders.get(i);rect(c,20,y,W-20,y+98,CARD,14);txt(c,icon(o.type),53,y+45,26,WHITE,false);txt(c,o.type,W-45,y+29,17,WHITE,true);txt(c,o.from+" ← "+o.to,W-45,y+54,13,MUTED,false);txt(c,o.time,W-45,y+77,11,MUTED,false);rect(c,W-120,y+64,W-35,y+90,GREEN,10);center(c,"تم الإرسال",W-77,y+82,10,WHITE,true);y+=108;}}bottom(c,1);}
    String icon(String s){if(s.contains("توصيل"))return "📦";if(s.contains("طالب"))return "🎓";if(s.contains("موظف"))return "💼";return "🚗";}
    void more(Canvas c){header(c,"المزيد");String[] x={"☎  اتصل الآن","☘  واتساب الآن","📍  موقعنا على الخريطة","↗  مشاركة التطبيق","ⓘ  عن التطبيق","⚙  الإعدادات"};float y=92;for(String s:x){rect(c,20,y,W-20,y+58,CARD,13);txt(c,s,W-40,y+37,17,WHITE,true);y+=68;}center(c,"Khoulyo",W/2,570,35,WHITE,true);center(c,"T U K T U K",W/2,592,11,MUTED,false);bottom(c,2);}
    void map(Canvas c){header(c,"موقعنا");rect(c,20,82,W-20,455,Color.rgb(218,220,210),18);center(c,"النبطية",W/2,145,20,Color.DKGRAY,true);center(c,"📍",W/2,280,50,RED,false);center(c,"كفررمان     تول     حبوش",W/2,390,16,Color.DKGRAY,true);button(c,"فتح في خرائط Google 🗺",480,RED);}
    void details(Canvas c){header(c,"تفاصيل الطلب");if(orders.size()==0){center(c,"لا يوجد طلب",W/2,240,18,MUTED,true);return;}Order o=orders.get(orders.size()-1);txt(c,o.type,W-30,105,21,WHITE,true);String[] k={"الحالة","الوقت","من","إلى","ملاحظات"};String[] v={"تم إرسال الطلب",o.time,o.from,o.to,o.note};float y=150;for(int i=0;i<k.length;i++){txt(c,k[i],W-30,y,14,MUTED,false);txt(c,v[i],W-30,y+28,17,WHITE,true);y+=62;}button(c,"إرسال التفاصيل عبر واتساب",500,GREEN);}
    void profile(Canvas c){header(c,"الملف الشخصي");rect(c,20,90,W-20,230,CARD,16);center(c,"●",W/2,145,68,WHITE,false);center(c,"Khoulyo",W/2,190,18,WHITE,true);center(c,"زائر",W/2,215,14,MUTED,false);button(c,"تعديل البيانات",255,CARD);rect(c,20,335,W-20,390,CARD,13);txt(c,"الوضع الليلي",W-50,370,17,WHITE,true);rect(c,W-100,350,W-50,378,BLUE,20);center(c,"●",W-75,370,18,WHITE,true);rect(c,20,405,W-20,460,CARD,13);txt(c,"اللغة        العربية",W-50,440,17,WHITE,true);center(c,"تسجيل الخروج",W/2,520,17,RED,true);}
    void notifications(Canvas c){header(c,"الإشعارات");notif(c,95,"🚗","طلب مشوار","تم تجهيز طلبك للإرسال عبر واتساب",RED);notif(c,195,"📦","توصيل أغراض","يمكنك متابعة طلبك من طلباتي",YELLOW);notif(c,295,"🎓","نقل طالب","تم حفظ بيانات الطلب",BLUE);}
    void notif(Canvas c,float y,String ic,String title,String sub,int col){rect(c,20,y,W-20,y+82,CARD,13);txt(c,ic,50,y+43,25,col,false);txt(c,title,W-50,y+29,16,WHITE,true);txt(c,sub,W-50,y+54,12,MUTED,false);}
    void bottom(Canvas c,int sel){float y=H-70;rect(c,0,y,W,H,BG,0);center(c,"⌂",W/6,y+30,25,sel==0?RED:WHITE,true);center(c,"الرئيسية",W/6,y+54,11,sel==0?RED:WHITE,true);center(c,"▤",W/2,y+30,23,sel==1?RED:WHITE,false);center(c,"طلباتي",W/2,y+54,11,sel==1?RED:WHITE,true);center(c,"⚙",W*5/6,y+30,23,sel==2?RED:WHITE,false);center(c,"المزيد",W*5/6,y+54,11,sel==2?RED:WHITE,true);}

    void ask(String label,String current,final int which){final EditText e=new EditText(a);e.setText(current);e.setSingleLine(true);e.setHint(label);e.setTextColor(Color.WHITE);e.setHintTextColor(MUTED);e.setBackgroundColor(Color.TRANSPARENT);LinearLayout box=new LinearLayout(a);box.setPadding(25,0,25,0);box.setBackgroundColor(CARD);box.addView(e,new LinearLayout.LayoutParams(-1,65));AlertDialog d=new AlertDialog.Builder(a).setTitle(label).setView(box).setNegativeButton("إلغاء",null).setPositiveButton("حفظ",null).create();d.setOnShowListener(x->{d.getButton(-1).setOnClickListener(v->{String s=e.getText().toString().trim();if(which==1)from=s;if(which==2)to=s;if(which==3)time=s;if(which==4)extra=s;if(which==5)type=s;invalidate();d.dismiss();});e.requestFocus();d.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);});d.show();}
    void send(){if(from.trim().isEmpty()||to.trim().isEmpty()){Toast.makeText(a,"اكتب مكان الانطلاق والوجهة",Toast.LENGTH_SHORT).show();return;}String title=page==1?"طلب مشوار":page==2?"توصيل أغراض":page==3?"نقل الطلاب":"نقل الموظفين";String now=new SimpleDateFormat("dd/MM/yyyy HH:mm",Locale.getDefault()).format(new Date());Order o=new Order(title,from,to,time,extra);orders.add(o);save();String msg="Khoulyo Tuktuk%0Aطلب جديد: "+title+"%0Aمن: "+from+"%0Aإلى: "+to+"%0Aالوقت: "+time+"%0Aملاحظات: "+extra+"%0Aالتاريخ: "+now; a.whatsapp(msg);page=5;invalidate();}
    @Override public boolean onTouchEvent(MotionEvent e){if(e.getAction()!=MotionEvent.ACTION_UP)return true;float x=e.getX(),y=e.getY();
        if(page==0){if(y>300&&y<395&&x<W/2)page=1;else if(y>300&&y<395)page=2;else if(y>395&&y<490&&x<W/2)page=3;else if(y>395&&y<490)page=4;else if(y>495&&y<555&&x<W/2){a.whatsapp("مرحبا Khoulyo Tuktuk");return true;}else if(y>495&&y<555){a.call();return true;}else if(y>H-85&&x>W*2/3)page=6;else if(y>H-85&&x>W/3)page=5;}
        else if(page==1||page==3||page==4){if(y<75)page=0;else if(y>105&&y<180)ask("مكان الانطلاق",from,1);else if(y>190&&y<265)ask(page==3?"المدرسة / الجامعة":"الوجهة",to,2);else if(y>275&&y<350)ask("الوقت",time,3);else if(y>360&&y<440)ask("ملاحظات",extra,4);else if(y>445&&y<525)send();}
        else if(page==2){if(y<75)page=0;else if(y>105&&y<180)ask("نوع الغرض",type,5);else if(y>190&&y<265)ask("مكان الاستلام",from,1);else if(y>275&&y<350)ask("مكان التسليم",to,2);else if(y>360&&y<440)ask("ملاحظات",extra,4);else if(y>445&&y<525)send();}
        else if(page==5){if(y<75)page=0;else if(y>H-85&&x>W*2/3)page=6;else if(y>140&&y<H-80&&orders.size()>0)page=8;}
        else if(page==6){if(y<75)page=0;else if(y>92&&y<155)a.call();else if(y>160&&y<225)a.whatsapp("مرحبا Khoulyo Tuktuk");else if(y>230&&y<295)page=7;else if(y>295&&y<365)a.openUrl("https://wa.me/?text="+Uri.encode("Khoulyo Tuktuk - النبطية و ضواحيها"));}
        else if(page==7){if(y<75)page=6;else if(y>470)a.openUrl("geo:33.3775,35.4833?q=33.3775,35.4833(Khoulyo+Tuktuk)");}
        else if(page==8){if(y<75)page=5;else if(y>490&&orders.size()>0){Order o=orders.get(orders.size()-1);a.whatsapp("تفاصيل طلب Khoulyo: "+o.type+" - من "+o.from+" إلى "+o.to);}}
        else if(page==9||page==10){if(y<75)page=0;}
        invalidate();return true;}
}
class Order{String type,from,to,time,note;Order(String t,String f,String to,String tm,String n){type=t;from=f;this.to=to;time=tm;note=n==null?"":n;}}
